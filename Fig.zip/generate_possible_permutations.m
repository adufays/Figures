function [vect] = generate_possible_permutations(kbar)

regime = 2^kbar;
vect = ones(kbar,regime);
for q=1:kbar
    ind = regime/2^q;
    etat = 1;
    count = 0;
    for z=1:regime
       if(count>=ind)
           count = 0;
           if(etat ==1)
               etat = 2;
           else
               etat = 1;
           end
       end
       count = count +1;
       vect(q,z) = etat;
    end
end
vect = vect-1;